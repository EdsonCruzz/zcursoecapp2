sap.ui.define(["zcursoecapp2/test/unit/controller/View1.controller"],function(){"use strict"});
//# sourceMappingURL=AllTests.js.map