/* global QUnit */

sap.ui.require(["zcursoecapp2/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
