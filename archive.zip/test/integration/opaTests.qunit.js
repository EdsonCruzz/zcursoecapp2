sap.ui.require(["zcursoecapp2/test/integration/AllJourneys"],function(){QUnit.config.autostart=false;QUnit.start()});
//# sourceMappingURL=opaTests.qunit.js.map