sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("zcursoecapp2.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  